-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: etl_db
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hetero85`
--

DROP TABLE IF EXISTS `hetero85`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `hetero85` (
  `Population` text,
  `Heterozygosit` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hetero85`
--

LOCK TABLES `hetero85` WRITE;
/*!40000 ALTER TABLE `hetero85` DISABLE KEYS */;
INSERT INTO `hetero85` VALUES ('Bedlington Terrier',0.312842),('Miniature Bull Terrier',0.321619),('Boxer',0.343151),('Clumber Spaniel',0.363595),('Greater Swiss Mountain Dog',0.364943),('Airedale Terrier',0.372793),('Soft Coated Wheaten Terrier',0.37376),('Collie',0.383453),('Doberman Pinscher',0.383763),('Irish Terrier',0.390427),('Bloodhound',0.391559),('German Shepherd Dog',0.397957),('Pug Dog',0.398442),('Bernese Mountain Dog',0.399599),('Flat-coated Retriever',0.402832),('Miniature Schnauzer',0.414528),('Irish Wolfhound',0.418039),('Pharaoh Hound',0.420188),('Cavalier King Charles Spaniel',0.427633),('Shetland Sheepdog',0.43244),('Manchester Terrier - Toy',0.432937),('French Bulldog',0.439855),('Basset Hound',0.441171),('American Cocker Spaniel',0.443841),('Schipperke',0.445437),('Irish Setter',0.446656),('Basenji',0.447739),('Bulldog',0.449549),('Standard Schnauzer',0.450041),('Whippet',0.450959),('American Hairless Terrier',0.454113),('Mastiff',0.455126),('Rottweiler',0.45651),('Pekingese',0.459983),('English Cocker Spaniel',0.46565),('Saint Bernard',0.465724),('Italian Greyhound',0.468797),('Afghan Hound',0.468924),('Pointer',0.469444),('Shih Tzu',0.472193),('Welsh Springer Spaniel',0.473917),('Kerry Blue Terrier',0.477836),('Dachshund',0.483817),('Borzoi',0.487909),('Great Dane',0.488697),('Alaskan Malamute',0.489877),('Newfoundland',0.490617),('West Highland White Terrier',0.493936),('Belgian Sheepdog',0.495114),('Australian Terrier',0.499343),('Ibizan Hound',0.503981),('Keeshond',0.505126),('Bullmastiff',0.509243),('Akita',0.510396),('Greyhound',0.513409),('Chesapeake Bay Retriever',0.514166),('Golden Retriever',0.517779),('Tibetan Terrier',0.519535),('Chow Chow',0.52043),('Rhodesian Ridgeback',0.520493),('Siberian Husky',0.527344),('Bichon Frise',0.528271),('Standard Poodle',0.529948),('Old English sheepdog',0.530192),('Norwegian Elkhound',0.532854),('German Shorthaired Pointer',0.538761),('American Water Spaniel',0.540183),('Lhasa Apso',0.541245),('Samoyed',0.542932),('Pomeranian',0.546007),('Beagle',0.549119),('Border Collie',0.549583),('Belgian Tervuren',0.551091),('Kuvasz',0.553538),('Shiba Inu',0.560543),('Labrador Retriever',0.56059),('Giant Schnauzer',0.56131),('Saluki',0.563037),('Portugurese Water Dog',0.568882),('Komondor',0.57321),('Cairn Terrier',0.575823),('Chinese Shar-Pei',0.584412),('Perro de Presa Canario',0.589397),('Chihuahua',0.592353),('Australian Shepherd',0.609668);
/*!40000 ALTER TABLE `hetero85` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-17 18:43:32
