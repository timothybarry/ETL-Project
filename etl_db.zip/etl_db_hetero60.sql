-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: etl_db
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hetero60`
--

DROP TABLE IF EXISTS `hetero60`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `hetero60` (
  `Breed` text,
  `Expected_Hetero` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hetero60`
--

LOCK TABLES `hetero60` WRITE;
/*!40000 ALTER TABLE `hetero60` DISABLE KEYS */;
INSERT INTO `hetero60` VALUES ('Scottish Deerhound',2.0683),('Field Spaniel',2.3165),('Flat-coated Retriever',2.6474),('Bernese Mountain Dog',2.8129),('Standard Schnauzer',2.8129),('Boxer',3.0611),('Collie',3.0611),('Bearded Collie',3.1438),('Miniature Bull Terrier',3.2266),('Perro de Presa Canario',3.392),('Bull Terrier',3.8057),('Mastiff',3.8057),('Petite Basset Griffon Vendeen',3.8884),('Bedlington Terrier',3.9712),('Saluki',4.1366),('Standard Poodle',4.1366),('Cavalier King Charles Spaniel',4.2194),('Sussex Spaniel',4.2194),('American Water Spaniel',4.5503),('Ibizan Hound',4.7158),('Beagle',4.7985),('Boston Terrier',4.7985),('German Pinscher',4.8812),('Basset Hound',4.964),('Bichon Frise',4.964),('Rottweiler',4.964),('Bullmastiff',5.1294),('English Springer Spaniel',5.1294),('Greater Swiss Mountain Dog',5.3776),('Pug Dog',5.3776),('Boykin Spaniel',5.5431),('Italian Greyhound',5.5431),('Newfoundland',5.5431),('American Hairless Terrier',5.7086),('Borzoi',5.7913),('German Shepherd Dog',5.7913),('Saint Bernard',5.7913),('Dachshund',5.874),('Akita',5.9568),('Cocker Spaniel',6.0395),('French Bulldog',6.0395),('Greyhound',6.0395),('Irish Water Spaniel',6.0395),('Shetland Sheepdog',6.205),('Papillon',6.2877),('Foxhound (English)',6.3704),('Tibetan Terrier',6.4532),('Welsh Springer Spaniel',6.4532),('German Shorthaired Pointer',6.6186),('Welsh Terrier',6.6186),('Dalmatian',6.7014),('Irish Setter',6.7014),('Alaskan Malamute',6.8668),('Golden Retriever',7.0323),('Portugese Water Dog',7.115),('Weimaraner',7.6942),('Labrador Retriever',8.4388),('Spinoni Italiano',8.9352),('Chesapeak Bay Retriever',9.1006),('English Shepherd',9.2661);
/*!40000 ALTER TABLE `hetero60` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-17 18:43:32
